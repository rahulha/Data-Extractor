﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrjDataExtraction
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable("Company");

        String FolderPath = "";


        public Form1()
        {
            InitializeComponent();

            dt.Columns.Add("SrID"); //0
            dt.Columns.Add("CompanyID"); //1
            dt.Columns.Add("CompanyName"); //2
            dt.Columns.Add("Date_Published"); //3
            dt.Columns.Add("Overall_Rating_Star"); //4
            dt.Columns.Add("Overall_Rating"); //5
            dt.Columns.Add("Financial_Rating Star"); //6
            dt.Columns.Add("Financial_Rating"); //7
            dt.Columns.Add("Accountability_Transparency_Rating_Star"); //8
            dt.Columns.Add("Accountability_Transparency_Rating"); //9
            dt.Columns.Add("Program_Expenses_Perc"); //10
            dt.Columns.Add("Administrative_Expenses_Perc"); //11
            dt.Columns.Add("Fundraising_Expenses_Perc"); //12
            dt.Columns.Add("Fundraising_Efficiency"); //13
            dt.Columns.Add("Primary_Revenue_Growth"); //14
            dt.Columns.Add("Program_Expenses_Growth"); //15
            dt.Columns.Add("Working_Capital_Ratio_years"); //16
            dt.Columns.Add("Primary_Revenue"); //17
            dt.Columns.Add("Contributions"); //18
            dt.Columns.Add("Program_Services"); //19
            dt.Columns.Add("Membership"); //20
            dt.Columns.Add("Other_Revenue"); //21
            dt.Columns.Add("Total_Revenue"); //22
            dt.Columns.Add("Program_Expenses"); //23
            dt.Columns.Add("Administrative_Expenses"); //24
            dt.Columns.Add("Fundraising_Expenses"); //25
            dt.Columns.Add("Payments_to_Affiliates"); //26
            dt.Columns.Add("Total_Functional_Expenses"); //27
            dt.Columns.Add("Excess_or_Deficit"); //28
            dt.Columns.Add("Assets"); //29
            dt.Columns.Add("Liabilities"); //30
            dt.Columns.Add("Net_Assets"); //31
            dt.Columns.Add("Working_Capital"); //32
            dt.Columns.Add("FYE"); //33

            dataGridView1.DataSource = dt;
        }


        private void btnExtract_Click(object sender, EventArgs e)
        {
            //rtbText.Text = '\n' + rtbText.Text;
            String[] txtLines = rtbText.Text.Split(new char[] { '\n' });
            int StopCounter = 4;

            while (!txtLines[StopCounter].Contains("Accountability & Transparency Rating"))
                StopCounter += 1;

            int PlaceCounter = 1;

            for (int i = 0; i <= StopCounter; i++)
            {
                String FYE = txtLines[i];
                if (FYE.Contains("FYE"))
                {
                    if (Convert.ToInt32(FYE.Substring(4).Trim()) > 2009 && Convert.ToInt32(FYE.Substring(4).Trim()) < 2014)
                    {
                        DataRow rw = dt.NewRow();

                        rw[33] = FYE.Substring(4).Trim(); //FYE

                        rw[2] = txtLines[1];//Company name

                        rw[3] = txtLines[2].Split(new char[] { ' ' })[PlaceCounter + 1]; //Date published

                        rw[5] = txtLines[PlaceCounter + 3]; //Overall rating

                        rw[7] = txtLines[i - 1]; //Financial rating

                        int tCounter = i;
                        while (!txtLines[tCounter].Contains("Accountability & Transparency Rating"))
                            tCounter += 1;

                        rw[9] = txtLines[tCounter].Split(new char[] { ' ' })[3 + PlaceCounter];// Accountability Transparancy rating

                        rw[10] = txtLines[tCounter + 2].Split(new char[] { ' ' })[1 + PlaceCounter]; //Program expence Perc

                        rw[11] = txtLines[tCounter + 3].Split(new char[] { ' ' })[PlaceCounter + 1];//Administrative_Expenses_Perc

                        rw[12] = txtLines[tCounter + 4].Split(new char[] { ' ' })[PlaceCounter + 1]; //Fundraising_Expenses_Perc

                        rw[13] = txtLines[tCounter + 5].Split(new char[] { ' ' })[PlaceCounter + 1]; //Fundraising_Efficiency

                        rw[14] = txtLines[tCounter + 6].Split(new char[] { ' ' })[PlaceCounter + 2]; //Primary_Revenue_Growth

                        rw[15] = txtLines[tCounter + 7].Split(new char[] { ' ' })[PlaceCounter + 2]; //Program_Expenses_Growth

                        rw[16] = txtLines[tCounter + 8].Split(new char[] { ' ' })[PlaceCounter + 3]; //Working_Capital_Ratio_years

                        tCounter += 9;

                        while (!txtLines[tCounter].Contains("Primary Revenue"))
                            tCounter += 1;


                        rw[17] = txtLines[tCounter].Split(new char[] { ' ' })[PlaceCounter + 1]; //Primary_Revenue

                        rw[18] = txtLines[tCounter + 1].Split(new char[] { ' ' })[PlaceCounter + 0]; //Contributions

                        rw[19] = txtLines[tCounter + 2].Split(new char[] { ' ' })[PlaceCounter + 1]; //Program_Services

                        rw[20] = txtLines[tCounter + 3].Split(new char[] { ' ' })[PlaceCounter + 0]; //Membership

                        rw[21] = txtLines[tCounter + 4].Split(new char[] { ' ' })[PlaceCounter + 1]; //Other_Revenue

                        rw[22] = txtLines[tCounter + 5].Split(new char[] { ' ' })[PlaceCounter + 1]; //Total_Revenue

                        rw[23] = txtLines[tCounter + 7].Split(new char[] { ' ' })[PlaceCounter + 1]; //Program_Expenses

                        rw[24] = txtLines[tCounter + 8].Split(new char[] { ' ' })[PlaceCounter + 1]; //Administrative_Expenses

                        rw[25] = txtLines[tCounter + 9].Split(new char[] { ' ' })[PlaceCounter + 1]; //Fundraising_Expenses

                        rw[26] = txtLines[tCounter + 10].Split(new char[] { ' ' })[PlaceCounter + 2]; //Payments_to_Affiliates

                        rw[27] = txtLines[tCounter + 11].Split(new char[] { ' ' })[PlaceCounter + 2]; //Total_Functional_Expenses

                        rw[28] = txtLines[tCounter + 12].Split(new char[] { ' ' })[PlaceCounter + 2]; //Excess_or_Deficit

                        rw[29] = txtLines[tCounter + 14].Split(new char[] { ' ' })[PlaceCounter + 0]; //Assets

                        rw[30] = txtLines[tCounter + 15].Split(new char[] { ' ' })[PlaceCounter + 0]; //Liabilities

                        rw[31] = txtLines[tCounter + 16].Split(new char[] { ' ' })[PlaceCounter + 1]; //Net_Assets

                        rw[32] = txtLines[tCounter + 17].Split(new char[] { ' ' })[PlaceCounter + 1]; //Working_Capital

                        dt.Rows.Add(rw);
                    }
                    PlaceCounter += 1;
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String FileText = "";

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    FileText += (dt.Rows[i][j].ToString().Contains(',') ? dt.Rows[i][j].ToString().Replace(",", @"") : dt.Rows[i][j].ToString()) + ",";
                }
                FileText += "\n";
            }

            if (FolderPath == "")
            {
                SaveFileDialog dlgCSVFile = new SaveFileDialog();
                if (dlgCSVFile.ShowDialog() == DialogResult.OK)
                {
                    FolderPath = dlgCSVFile.FileName;
                }
            }

            System.IO.File.AppendAllText(FolderPath + ".csv", FileText);
            dt.Rows.Clear();
        }
    }
}
